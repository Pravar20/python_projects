"""
Author:         Pravar Kochar
Date:           3/2/2023
E-mail:         pkochar1@umbc.edu
Description:    A class implementation for HW1 functions, import cars.csv,
and use it.
"""

# Imports
import csv
import numpy
import math
import matplotlib.pyplot as plot


class Data:
    def __init__(self):
        # Self variables
        self.cars_file_name = "cars.csv"
        self.mpg = "mpg"
        self.weight = "weight"
        self.scaled_w = "scaled_weight"
        self.delim = ','
        self.cars_data = {self.mpg: [], self.weight: [], self.scaled_w: []}
        self.data_count = 0
        self.scaled_mean = 0
        self.scaled_variance = 0
        # y-values to plot for e) vs x-val as scaled_w
        self.gd_cost_fn = {.10: [], .15: [], .20: [], .25: [], .30: []}

        # Self call
        self.init_cars()

    def init_cars(self):
        """
        A initialization function that reads and initializes the variables
        from the .csv file.
        :return: None
        """
        with open(self.cars_file_name, newline='') as cars:
            file_data = csv.reader(cars, delimiter=self.delim)
            # Go through each row.
            for row in file_data:
                # if the row is a data row.
                if row != [self.mpg, self.weight]:
                    self.data_count += 1  # Keep a count
                    # put in directory while type casting to float.
                    self.cars_data[self.mpg].append(float(row[0]))
                    self.cars_data[self.weight].append(float(row[1]))

    def sw_pre_process(self):
        """
        A function to calculate the mean and variance of the weights.
        :return: None
        """
        return numpy.mean(self.cars_data[self.weight]), numpy.var(self.cars_data[self.weight])

    def calc_scaled_weight(self):
        """
        A function to calculate and store the scaled weights it's mean and variance.
        :return: None
        """
        weight_mean, weight_variance = self.sw_pre_process()
        # Calc and store each scaled weight.
        for weight in self.cars_data[self.weight]:
            sw = (weight - weight_mean) / math.sqrt(weight_variance)
            self.cars_data[self.scaled_w].append(sw)

        # Calc and store the scaled mean and variance.
        self.scaled_mean = numpy.mean(self.cars_data[self.scaled_w])
        self.scaled_variance = numpy.var(self.cars_data[self.scaled_w])

    def print_scaled_weights_and_mean_var(self):
        """
        Required print fn. Prints scaled weights (first 5), and the mean and variance of scaled
        weight.
        :return: None.
        """
        print("First 5 scaled weights:")
        for sc_w in self.cars_data[self.scaled_w][:5]:
            print('\t', format(sc_w, '.5f'))

        print("Scaled weight mean: ", format(self.scaled_mean, '.5f'), "\nScaled weight variance: ",
              format(self.scaled_variance, '.5f'))

    def plot_scatter_plot(self, x_val, y_val, title='', x_label='', y_label=''):
        """
        A function to plot a scatter plot and show it.
        :return: None
        """
        plot.scatter(x_val, y_val)
        plot.title(title)
        plot.axvline(x=0, c='black', label='x_axis')
        plot.axhline(y=0, c='black', label='y_axis')
        plot.xlabel(x_label)
        plot.ylabel(y_label)
        plot.legend()
        plot.grid()
        plot.show()

    def gradient_descent(self, learning_rate=.20, theta_0_new=0, theta_1_new=0,
                         convergence_threshold=10 ** -5):
        """
        A function to find the minimum of the hypothesis, h_theta (x) := theta_0 + theta_1*x
        :param theta_0_new: y-intercept of the hypothesis.
        :param theta_1_new: Slope of the hypothesis equation.
        :param learning_rate: The learning rate/alpha.
        :param convergence_threshold: The threshold until convergence.
        :return: Theta_0_cap, Theta_1_cap values.
        """
        # Set the current value as the old values.
        theta_0_old, theta_1_old = theta_0_new, theta_1_new
        # Re-calc new theta values.
        theta_0_new, theta_1_new = self.update_theta(theta_0_old, theta_1_old, learning_rate)
        # Save the cost function value for the current learning rate and iteration.
        self.gd_cost_fn[learning_rate] = [self.cost_fn(theta_0_new, theta_1_new)]

        while (not (self.is_converging(theta_0_old, theta_0_new, convergence_threshold) and
                    self.is_converging(theta_1_old, theta_1_new, convergence_threshold))):
            # Set the current value as the old values.
            theta_0_old, theta_1_old = theta_0_new, theta_1_new
            # Re-calc new theta values.
            theta_0_new, theta_1_new = self.update_theta(theta_0_old, theta_1_old, learning_rate)
            # Append the cost function value for the current learning rate and iteration.
            self.gd_cost_fn[learning_rate].append(self.cost_fn(theta_0_new, theta_1_new))

        # Here the values are converged.
        return theta_0_new, theta_1_new

    def update_theta(self, t0_old, t1_old, alpha):
        """
        A function to calculate both theta new values, t_old - alpha partial derivative of J(theta)
        w.r.t. theta.
        :param t0_old: theta_0_old of the hypothesis
        :param t1_old: theta_1_old, of the hypothesis
        :param alpha: Learning rate
        :return: theta_new values (theta_0_new, theta_1_new)
        """
        m = self.data_count  # data size

        # Calculate the partial derivative value for theta_0 and theta_1.
        pd0 = 0
        pd1 = 0
        for i in range(0, m):
            x_i = self.cars_data[self.scaled_w][i]
            y_i = self.cars_data[self.mpg][i]
            pd0 += (t0_old + (t1_old * x_i) - y_i)
            pd1 += (t0_old + (t1_old * x_i) - y_i) * x_i
        pd0 = pd0 / m
        pd1 = pd1 / m

        # Return the theta values.
        return t0_old - (alpha * pd0), t1_old - (alpha * pd1)

    def cost_fn(self, t0, t1):
        """
        A function to calculate the value of the cost function.
        :param t0: theta_0
        :param t1: theta_1
        :return: j_theta: J(theta) value.
        """
        j_theta = 0  # Cost function value
        m = self.data_count  # data size

        # Calculate the value of J(theta) summation part.
        for i in range(0, m):
            x_i = self.cars_data[self.scaled_w][i]
            y_i = self.cars_data[self.mpg][i]
            j_theta += (t0 + (t1 * x_i) - y_i) ** 2
        j_theta = j_theta / (2 * m)

        # Return the cost function value.
        return j_theta

    def is_converging(self, val_old, val_new, threshold):
        """
        Helper for gradient descent while condition. |theta_new - theta_old| < C
        """
        return abs(val_new - val_old) < threshold

    def cost_fn_plot(self):
        for each_rate in [.10, .15, .20, .25, .30]:
            plot.plot(range(0, len(self.gd_cost_fn[each_rate])), self.gd_cost_fn[each_rate],
                      label=f'{each_rate}')

        plot.title("Cost function change over different learning rate")
        plot.xlabel('Iteration')
        plot.ylabel('Cost function value')
        plot.legend()
        plot.grid()
        plot.show()

    def plot_trend_line(self, theta_0, theta_1, x_val, y_val, title='', x_label='', y_label=''):
        """
        A function to plot a scatter plot and show it.
        :return: None
        """
        plot.scatter(x_val, y_val)
        x = numpy.linspace(-2, 3, 50)
        y = theta_1 * x + theta_0
        plot.plot(x, y, '-r', label='Hypothesis h_theta')
        plot.title(title)
        plot.axvline(x=0, c='black', label='x_axis')
        plot.axhline(y=0, c='black', label='y_axis')
        plot.xlabel(x_label)
        plot.ylabel(y_label)
        plot.legend()
        plot.grid()
        plot.show()
