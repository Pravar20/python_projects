"""
Author:         Pravar Kochar
Date:           4/19/2023
E-mail:         pkochar1@umbc.edu
Description:    A class to hold all the variable names for HW3 functions.
"""


class Var:
    def __init__(self, var_lst):
        self.DEFAULT_LR = .2
        # 2 list to store the variables and the scaled responses variable name, for keys.
        self.vr_list = var_lst
        self.ft_vr_lst = self.vr_list[1:]
        self.sc_ft_vr_lst = []

        # Define the response and features.
        self.vr_response = var_lst[0]
        # Send all but fist variable, its the response
        self.__populate_scaled_vr_lst(var_lst[1:])
        self.learning_rate = [self.DEFAULT_LR]

        self.GD_FLAG_LIN_REG = 'multiple_linear_reg'
        self.GD_FLAG_LOG_REG = 'logistic_reg'

    def __populate_scaled_vr_lst(self, lst):
        scaled_prefix = 'scaled_'
        for vr in lst:
            self.sc_ft_vr_lst.append(scaled_prefix + vr)
