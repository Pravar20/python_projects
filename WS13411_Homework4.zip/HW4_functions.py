"""
Author:         Pravar Kochar
Date:           5/6/2023
E-mail:         pkochar1@umbc.edu
Description:    A class implementation for HW4 functions.
"""

# Imports
import copy
from variables import Var
import csv
import numpy
import math
from tabulate import tabulate
import matplotlib.pyplot as plot
import numpy as np
from IPython.display import display, Latex


def get_mean_var(lst):
    """
    A function to calculate the mean and variance of the given list.
    :return: mean and variance value.
    """
    return numpy.mean(lst), numpy.var(lst)


def ridge_plot(ridge_param, thetas):
    # Go over the thetas (10 theta in cars.csv -the bias)
    for i in range(1, len(thetas[0])):
        # x-val is ridge_param list.
        # The y-val.
        line_plot = [theta_lst[i] for theta_lst in thetas]
        # plot the theta_i list.
        plot.plot(ridge_param, line_plot, label=f'theta_{i}')

    plot.title("Ridge trace plot")
    plot.xlabel('Ridge parameter')
    plot.ylabel('Standardized Coefficients')
    plot.legend(loc="upper left", bbox_to_anchor=(1, 1))
    plot.grid()
    plot.show()


class Data:
    def __init__(self, file_name, is_log_reg=False, features=None):
        """
        Initialize for the given file and what type of GD to run.
        :param file_name: The data .csv file.
        :param is_log_reg: if logistic regression data or not.
        :type is_log_reg: bool
        """

        # Self variables
        self.file_name = file_name
        self.delim = ','

        # Raw data storage.
        self.raw_data = {}
        self.data_count = 0

        # Self call to populate raw data, and save the variables    .
        self.vr = Var(self.init_raw_data(features))

        # Scaled data storage initialize.
        self.scaled_data = self.init_lst_to_dir(self.vr.sc_ft_vr_lst)

        self.sc_mean_var = {key: None for key in self.vr.sc_ft_vr_lst}
        # Save the gd_cost for each run.
        self.gd_cost_fn = {learn_rt: [] for learn_rt in self.vr.learning_rate}

        # 0 all theta (len(ft) + 1) (theta_0 = 0)
        self.zero_lst = [0 for _ in self.vr.vr_list]

        if is_log_reg:
            self.__GD_type = self.vr.GD_FLAG_LOG_REG
        else:
            self.__GD_type = self.vr.GD_FLAG_LIN_REG

        self.prediction_lst = None
        self.SS_residual = None
        self.SS_total = None
        self.r_squared = None
        self.adjusted_r_sq = None

    def init_raw_data(self, ft_count):
        """
        A initialization function that reads and initializes the variables
        from the .csv file.
        :param ft_count: The number of features to use.
        :return: None
        """
        var_lst = []
        first_line = True

        with open(self.file_name, newline='') as csv_fl:
            # read the file data.
            file_data = csv.reader(csv_fl, delimiter=self.delim)

            # Go through each row, row -> lst.
            for row in file_data:
                # Save first line as variables.
                if first_line:
                    # If want to use all features.
                    if ft_count is None:
                        ft_count = len(row)

                    var_lst = row[:ft_count + 1]  # +1 for response
                    first_line = False
                    # init raw data as directory.
                    self.raw_data = self.init_lst_to_dir(var_lst)

                else:  # row is a data row, save it.
                    self.data_count += 1  # Keep a count
                    # put in directory while type casting to float.
                    for key, idx in zip(var_lst, range(len(var_lst))):
                        self.raw_data[key].append(float(row[idx]))

        # return the variable lst.
        return var_lst

    def init_lst_to_dir(self, key_lst):
        return {key: [] for key in key_lst}

    def calc_scaled_feature(self, feature, scaled_ft):
        """
        A function to calculate and store the scaled feature's mean and variance.
        :return: None
        """
        ft_mean, ft_variance = get_mean_var(self.raw_data[feature])
        # Calc and store each scaled feature.
        for each_data in self.raw_data[feature]:
            sc_ft = (each_data - ft_mean) / math.sqrt(ft_variance)
            self.scaled_data[scaled_ft].append(sc_ft)

        # Calc and store the scaled mean and variance.
        self.sc_mean_var[scaled_ft] = (get_mean_var(self.scaled_data[scaled_ft]))

    def scale_features(self):
        """
        A function to scale each given feature.
        :return: None.
        """
        # Logistic data can't be scaled, so just copy it.
        if self.__GD_type == self.vr.GD_FLAG_LOG_REG:
            for each_ft, each_sc_ft in zip(self.vr.ft_vr_lst, self.vr.sc_ft_vr_lst):
                self.scaled_data[each_sc_ft] = self.raw_data[each_ft][:]
        else:  # Linear data can be scaled.
            for each_ft, each_sc_ft in zip(self.vr.ft_vr_lst, self.vr.sc_ft_vr_lst):
                self.calc_scaled_feature(each_ft, each_sc_ft)

    def print_error_of_pred(self, pred_lst, heading_3="Predicted milage",
                            heading_4="Error in milage"):
        """
        Required print fn. Prints observed & estimated response along with the error.
        """
        idx = [i for i in range(1, self.data_count + 1)]
        obs_resp = self.raw_data[self.vr.vr_response]
        error_lst = [format(abs(pred - obs), '.4f') for pred, obs in zip(pred_lst, obs_resp)]
        pred_lst = [format(pred, '.4f') for pred in pred_lst]

        table = {"Car instance": idx, "Observed milage": obs_resp, heading_3: pred_lst,
                 heading_4: error_lst}
        print(tabulate(table, headers="keys", tablefmt="outline", numalign="center"))

    def plot_scatter_plot(self, x_val, y_val, title='', x_label='', y_label=''):
        """
        A function to plot a scatter plot and show it.
        :return: None
        """
        plot.scatter(x_val, y_val)
        plot.title(title)
        plot.axvline(x=0, c='black', label='x_axis')
        plot.axhline(y=0, c='black', label='y_axis')
        plot.xlabel(x_label)
        plot.ylabel(y_label)
        plot.legend()
        plot.grid()
        plot.show()

    def gradient_descent(self, instance_idx_ignore=None, learning_rate=None,
                         convergence_threshold=None, lambda_param=None, theta_new=None):
        """
        A function to find the minimum of the hypothesis, h_theta (x) := theta_0 + theta_1*x
        :param theta_new: list of theta. (default to zero list if a not provided/wrong lst len)
        :param learning_rate: The learning rate/alpha.
        :param convergence_threshold: The threshold until convergence.
        :param instance_idx_ignore: The data indices to ignore in finding the GD.
        :param lambda_param: Regularization parameter.
        :return: Theta values.
        :type: List
        """
        if instance_idx_ignore is None:
            instance_idx_ignore = []
        if learning_rate is None:
            learning_rate = self.vr.DEFAULT_LR
        if convergence_threshold is None:
            convergence_threshold = 10 ** -5
        if theta_new is None:
            theta_new = self.zero_lst
        elif len(theta_new) != len(self.zero_lst):
            raise ValueError("Theta list of invalid size.")

        # Set the current theta as the old ones using list slicing.
        theta_old = theta_new[:]
        # Re-calc new theta values.
        theta_new = self.update_theta(theta_old, learning_rate, instance_idx_ignore, lambda_param)

        # Save the cost function value for the current learning rate and iteration.
        self.gd_cost_fn[learning_rate] = [self.cost_fn(theta_new, instance_idx_ignore, lambda_param)]

        while not self.is_converging(theta_old, theta_new, convergence_threshold):
            # Set the current value as the old values.
            theta_old = theta_new[:]
            # Re-calc new theta values.
            theta_new = self.update_theta(theta_old, learning_rate, instance_idx_ignore, lambda_param)
            # Append the cost function value for the current learning rate and iteration.
            self.gd_cost_fn[learning_rate].append(self.cost_fn(theta_new, instance_idx_ignore, lambda_param))

        # Here the values are converged.
        return theta_new

    def update_theta(self, theta_lst_old, alpha, inst_ignore_idx_lst, lambda_para):
        """
        A function to calculate all theta new values, t_old - alpha * partial derivative of J(theta)
        w.r.t. theta.
        :param theta_lst_old: List of all the old theta values.
        :param alpha: Learning rate
        :param inst_ignore_idx_lst: The list of indices to ignore as the test data.
        :param lambda_para: Regularization parameter.
        :return: theta_new values
        :type: list
        """
        m = self.data_count - len(inst_ignore_idx_lst)  # data size
        theta_lst_old = np.array(theta_lst_old)

        # Calculate the partial derivative value for all theta.
        pd_lst = [0 for theta in theta_lst_old]

        for i in range(self.data_count):  # Go over all data.
            if i not in inst_ignore_idx_lst:
                # x array of all i^th instance.
                x_i_lst = [self.scaled_data[sc_ft][i] for sc_ft in self.vr.sc_ft_vr_lst]
                x_i_lst[:0] = [1]  # add the bias, x_0 to be 1.
                # Response scaler val.
                y_i = self.raw_data[self.vr.vr_response][i]

                # calculate the hypothesis at the given x^(i).
                hypothesis = self.hypo_calc(theta_lst_old, np.array(x_i_lst))
                # Update the pd list.
                pd_lst = [pd_lst[idx] + ((hypothesis - y_i) * x_i_lst[idx])
                          for idx in range(len(pd_lst))]

        # Regularize the pd_values.
        if lambda_para is not None:
            for j in range(0, len(pd_lst)):
                # Dont change bias.
                if j == 0:
                    pd_lst = [pd_lst[0] / m] + pd_lst[1:]
                else:
                    pd_lst[j] = (pd_lst[j] + (lambda_para * theta_lst_old[j])) / m

                    #pd_lst = [(hypo_pd + (lambda_para * theta_j)) / m for hypo_pd, theta_j in
                    # zip(pd_lst, theta_lst_old)]
        # Don't regularize.
        else:
            pd_lst = [each_pd / m for each_pd in pd_lst]

        # Return the theta values.
        ret_theta_lst = [theta_lst_old[j] - (alpha * pd_lst[j]) for j in range(len(pd_lst))]
        return ret_theta_lst

    def cost_fn(self, theta_lst, inst_ignore_idx_lst, reg_param):
        """
        A function to calculate the value of the cost function.
        :param theta_lst: The list of all the theta.
        :param inst_ignore_idx_lst: The list of indices to ignore as the test data.
        :param reg_param: Regularization parameter.
        :return: j_theta: J(theta) value.
        """
        if self.__GD_type == self.vr.GD_FLAG_LOG_REG:
            reg_param = None

        j_theta = 0  # Cost function value
        m = self.data_count - len(inst_ignore_idx_lst)  # data size

        # A 2d list of all the i's of features.
        x_i_lst = []
        for sc_ft in self.vr.sc_ft_vr_lst:
            sc_dt_lst = self.scaled_data[sc_ft][:]  # Make copy.
            # Cut the ignore idx from list.
            sc_dt_lst = self.cut_indices_from_lst(sc_dt_lst, inst_ignore_idx_lst)
            x_i_lst.append(sc_dt_lst)  # Append the correct cut data lst.
        # Also cut the response lst.
        resp_lst = self.cut_indices_from_lst(self.raw_data[self.vr.vr_response][:],
                                             inst_ignore_idx_lst)

        x_i_lst[:0] = [[1 for each_i in x_i_lst[0]]]  # Add a list of 1's to make X vector.
        # Convert to array.
        theta_lst = np.array(theta_lst)

        # Calculate the value of J(theta) summation part.
        for i in range(m):  # Go over data.
            x_i = [x_i_lst[ft_idx][i] for ft_idx in range(len(x_i_lst))]
            x_i = np.array(x_i)
            y_i = resp_lst[i]

            # To calc hypo val (depending on logistic or linear regression)
            hypothesis = self.hypo_calc(theta_lst, x_i.transpose())

            if self.__GD_type == self.vr.GD_FLAG_LIN_REG:
                j_theta += (hypothesis - y_i) ** 2
            elif self.__GD_type == self.vr.GD_FLAG_LOG_REG:
                j_theta += self.logistic_cost(hypothesis, y_i)

        # Regularize J(theta).
        if reg_param is not None:
            theta_sq_sum = 0
            # Exclude first bias.
            for theta in theta_lst[1:]:
                theta_sq_sum += theta ** 2

            # J(theta) = MLR sum part + lambda * sum(theta^2), theta: 1->n
            j_theta += reg_param * theta_sq_sum

        if self.__GD_type == self.vr.GD_FLAG_LIN_REG:
            j_theta = j_theta / (2 * m)
        elif self.__GD_type == self.vr.GD_FLAG_LOG_REG:
            j_theta = j_theta / m

        # Return the cost function value.
        return j_theta

    def logistic_cost(self, h_theta_i, y_i):
        """
        Helper to get the cost of the instance of i, cross-entropy cost function.
        """
        if int(y_i) == 0:
            return -math.log(1 - h_theta_i, math.e)
        elif int(y_i) == 1:
            return -math.log(h_theta_i, math.e)
        else:
            raise Exception("y_i not binary.")

    def cut_indices_from_lst(self, lst, del_idx_lst):
        """
        A function to delete the indexes given in from of list from a list.
        :param lst: The list to delete elements from.
        :param del_idx_lst: The list of indices to delete from.
        :return: Cut list.
        """
        # Reverse sort so bigger index gets deleted first so index to delete doesn't change.
        for idx in sorted(del_idx_lst, reverse=True):
            del lst[idx]
        return lst

    def hypo_calc(self, theta_lst, x_i_lst, decision_boundary=False):
        """
        Calc and return the hypothesis based on the given theta list, and x_i list.
        :param theta_lst: The theta list that is calculated.
        :param x_i_lst: The x_i list that is given.
        :param decision_boundary: If override for decision boundary calculations.
        :return: A scaler for the given hypothesis.
        """
        # do linear regression calc, unless doing decision boundary.
        if self.__GD_type == self.vr.GD_FLAG_LIN_REG or decision_boundary is True:
            # Calc theta^T * X
            return np.matmul(theta_lst, x_i_lst)
        # do logistic regression calc.
        elif self.__GD_type == self.vr.GD_FLAG_LOG_REG:  # do logistic regression.
            # Calc 1/(1+e^(-theta^T * X))
            return (1 + math.exp(-1 * np.matmul(theta_lst, x_i_lst))) ** -1

    def is_converging(self, val_old_lst, val_new_lst, threshold):
        """
        Helper for gradient descent while condition. |theta_new - theta_old| < C
        """
        converging = True
        for old_val, new_val in zip(val_old_lst, val_new_lst):
            converging = converging and (abs(new_val - old_val) < threshold)
        return converging

    def cost_fn_plot(self):
        for each_rate in self.vr.learning_rate:
            plot.plot(range(0, len(self.gd_cost_fn[each_rate])), self.gd_cost_fn[each_rate],
                      label=f'LR={each_rate}')

        plot.title("Cost function change over different learning rate")
        plot.xlabel('Iteration')
        plot.ylabel('Cost function value')
        plot.legend()
        plot.grid()
        plot.show()

    def normal_equation(self, inst_ignore_lst=None, lambda_param=None):
        """
        A function that uses normal equation method to find the theta values
        (Linear Regression specific).
        :param inst_ignore_lst: The instances to ignore.
        :param lambda_param: The regularization_param to regularize the model.
        :return: Theta list.
        """
        if self.__GD_type == self.vr.GD_FLAG_LOG_REG:
            raise ValueError("Can't run normal_equation() for logistic regression.")

        m = self.data_count

        # Create and store the X and X transpose array separately.
        X_trans = [copy.deepcopy(inst_lst) for inst_lst in self.scaled_data.values()]

        if inst_ignore_lst is not None:
            m -= len(inst_ignore_lst)
            for each_param_lst in X_trans:
                each_param_lst = self.cut_indices_from_lst(each_param_lst, inst_ignore_lst)

        # Add the x_0's as 1's.
        X_trans[:0] = [[1 for _ in range(m)]]
        X = X_trans.copy()

        X_trans = np.array(X_trans)
        X = np.array(X).transpose()

        Y = copy.deepcopy(self.raw_data[self.vr.vr_response])

        if inst_ignore_lst is not None:
            Y = self.cut_indices_from_lst(Y, inst_ignore_lst)

        Y = np.array(Y).transpose()

        if lambda_param is not None:
            # Define the I~ matrix.
            I_tilde = np.identity(X.shape[1])
            I_tilde[0, 0] = 0.
            inverse = np.matmul(X_trans, X) + (lambda_param * I_tilde)
        else:
            inverse = np.matmul(X_trans, X)

        # Common irrespective of regularization.
        inverse = np.linalg.inv(inverse)
        xt_y = np.matmul(X_trans, Y)

        theta_lst = np.matmul(inverse, xt_y)
        return theta_lst.tolist()

    def resp_prediction(self, theta_lst, decision_boundary_override=False):
        """
        A function that given the theta list tells the predicted response.
        :return: prediction list
        """
        if self.__GD_type == self.vr.GD_FLAG_LIN_REG:
            decision_boundary_override = False

        respo_lst = []
        # For each car save the prediction.
        m = self.data_count
        for i in range(m):
            x_i_lst = [self.scaled_data[sc_ft][i] for sc_ft in self.vr.sc_ft_vr_lst]
            x_i_lst[:0] = [1]  # add x_0 to be 1.
            # For logistic regression get the decision boundary instead.
            response = self.hypo_calc(theta_lst, np.array(x_i_lst), decision_boundary_override)
            if decision_boundary_override is True:
                if response > 0:
                    response = 1
                else:
                    response = 0

            respo_lst.append(response)

        self.prediction_lst = respo_lst
        return respo_lst

    def resp_pred_test_data(self, theta_lst, test_dt_idx_lst):
        """
        A function that given the theta list tells the predicted response for the test data.
        :return: prediction list
        """
        respo_lst = []
        # For each car save the prediction.
        m = len(test_dt_idx_lst)
        for idx in test_dt_idx_lst:
            x_i_lst = [self.scaled_data[sc_ft][idx] for sc_ft in self.vr.sc_ft_vr_lst]
            x_i_lst[:0] = [1]  # add x_0 to be 1.
            respo_lst.append(self.hypo_calc(theta_lst, np.array(x_i_lst)))

        return respo_lst

    def calc_r_squared(self, pred_lst=None):
        if pred_lst is None:
            if self.prediction_lst is None:
                raise ValueError("Can't call r^2 before prediction is calculated.")
            else:
                pred_lst = self.prediction_lst

        m = self.data_count

        y_i_lst = self.raw_data[self.vr.vr_response]
        avg_response = np.average(y_i_lst)

        res_sum = 0
        tot_sum = 0
        for y_i, y_cap in zip(y_i_lst, pred_lst):
            res_sum += (y_i - y_cap) ** 2
            tot_sum += (y_i - avg_response) ** 2

        self.SS_residual = res_sum / m
        self.SS_total = tot_sum / m
        self.r_squared = 1 - (self.SS_residual / self.SS_total)
        return self.r_squared

    def calc_adj_r_sq(self):
        if self.r_squared is None:
            raise ValueError("Can't call adjusted r^2 before calling r^2.")

        m = self.data_count
        n = len(self.vr.sc_ft_vr_lst)  # length of features.
        self.adjusted_r_sq = 1 - (1 - self.r_squared) * ((m - 1) / (m - n))
        return self.adjusted_r_sq

    def print_logistic_pred(self, pred_lst, heading_idx='Index', heading_obs='Responses',
                            heading_pred='Prediction of response', print_float=False):
        idx = [i for i in range(1, self.data_count + 1)]
        obs_resp = self.raw_data[self.vr.vr_response]

        if print_float is True:
            pred_lst = [format(pred, '.4f') for pred in pred_lst]

        table = {heading_idx: idx, heading_obs: obs_resp, heading_pred: pred_lst}
        print(tabulate(table, headers="keys", tablefmt="outline", numalign="center"))

    def calc_print_confusion_matrix(self, pred_lst, _1='', _0=''):
        """
        A function to calculate and print the confusion matrix, and print the percentage of
        correct classification, precision, recall, specificity, and F1 score.
        """
        if self.__GD_type == self.vr.GD_FLAG_LIN_REG:
            raise ValueError(
                "calc_print_confusion_matrix(): Can't run on a linear regression model.")
        obs_lst = [int(obs) for obs in self.raw_data[self.vr.vr_response]]
        """
        Confusion matrix encoding.
        [ 00 01 ]
        [ 10 11 ]   mat(obs, pred)
            00 - true-negative      01 - false-positive
            10 - false-negative     11 - true-positive
        """
        conf_mat = [[0, 0],
                    [0, 0]]
        # count in the confusion matrix.
        for obs, pred in zip(obs_lst, pred_lst):
            conf_mat[obs][pred] += 1

        print('\t' * 7 + "Confusion matrix")
        conf_table = {
            "Observation\\Prediction": ["Observed " + _1, "Observed " + _0],
            "Predicted " + _1: [conf_mat[1][1], conf_mat[0][1]],
            "Predicted " + _0: [conf_mat[1][0], conf_mat[0][0]]
        }
        print(tabulate(conf_table, headers="keys", tablefmt="outline", numalign="center"))

        # Prec of correct class: (TP + TN) / m
        corr_class = (conf_mat[1][1] + conf_mat[0][0]) / len(obs_lst)
        display(Latex(f"$Percentage\ of\ correct\ classification = {format(corr_class, '.4f')}$"))

        # Precision: TP / PP
        precision = conf_mat[1][1] / (conf_mat[0][1] + conf_mat[1][1])
        display(Latex(f"$Precision = {format(precision, '.4f')}$"))

        # Recall: TP / P
        recall = conf_mat[1][1] / (conf_mat[1][0] + conf_mat[1][1])
        display(Latex(f"$Sensitivity\ of\ Recall = {format(recall, '.4f')}$"))

        # Specificity: TN / N
        display(Latex(
            f"$Specificity = {format(conf_mat[0][0] / (conf_mat[0][1] + conf_mat[0][0]), '.4f')}$"))

        # F1 Score: 2 / (1/precision + 1/recall)
        display(Latex(f"$F_{{1}} = {format(2 / ((1 / precision) + (1 / recall)), '.4f')}$"))

    def odds_ratio(self, theta_lst):
        """
        Print odds ratio for 1 feature.
        """
        OR = math.exp(theta_lst[1])
        print(f"Odds of cancer given smoking over odds of cancer given non-smoker: {OR}")

    def report_thetas(self, theta_lst):
        """
        Print the given thetas.
        :param theta_lst: Thetas given.
        """
        print_str = ''
        print("Model parameters (Thetas):")
        for i, theta in zip(range(len(theta_lst)), theta_lst):
            print_str += f"${{\Theta}}_{{{i}}} = {format(theta, '.4f')}$\n"
        display(Latex(print_str))


if __name__ == '__main__':
    pass
