"""
Author:         Pravar Kochar
Date:           4/19/2023
E-mail:         pkochar1@umbc.edu
Description:    A class to hold all the raw data from csv file.
"""

import csv


class CsvData:
    def __init__(self, file_name, is_log_reg=False, features=None):
        """
        Initialize for the given file and what type of GD to run.
        :param file_name: The data .csv file.
        :param is_log_reg: if logistic regression data or not.
        :type is_log_reg: bool
        """
        self.DELIM = ','

        # Self variables
        self.file_name = file_name

        # Raw data storage.
        self.raw_data = []
        self.data_count = 0

        # Store name of variables.
        self.ft_vr_lst = []
        self.num_ft = 0
        self.response_vr = None

        self.init_raw_data()

    def init_raw_data(self):
        """
        A initialization function that reads and initializes the variables
        from the .csv file.
        """
        var_lst = []
        first_line = True

        with open(self.file_name, newline='') as csv_fl:
            # read the file data.
            file_data = csv.reader(csv_fl, delimiter=self.DELIM)

            # Go through each row, row -> lst.
            for row in file_data:
                # Save first line as variables.
                if first_line:
                    var_lst = row[:]
                    first_line = False
                    # Set the variable names.
                    self.ft_vr_lst = var_lst[1:]
                    self.num_ft = len(self.ft_vr_lst)
                    self.response_vr = var_lst[0]

                else:  # row is a data row, save it.
                    self.data_count += 1  # Keep a count
                    self.raw_data.append([row[0], [float(dt) for dt in row[1:]]])
                    """# put in directory while type casting to float.
                    for key, idx in zip(var_lst, range(len(var_lst))):
                        if key != self.response_vr:
                            self.raw_data[key].append(float(row[idx]))
                        else:
                            self.raw_data[key].append(str(row[idx]))"""

