"""
Author:         Pravar Kochar
Date:           4/1/2023
E-mail:         pkochar1@umbc.edu
Description:    A class implementation for HW2 functions, import cars.csv,
and use it.
"""

# Imports
from variables import Var
import csv
import numpy
import math
from tabulate import tabulate
import matplotlib.pyplot as plot
import numpy as np


class Data:
    def __init__(self):
        # Self variables
        self.cars_file_name = "cars.csv"
        self.vr = Var()
        self.delim = ','
        # Raw data storage.
        self.cars_raw_data = {key: [] for key in self.vr.vr_list}
        # Scaled data storage.
        self.cars_scaled = {key: [] for key in self.vr.sc_vr_list}
        self.data_count = 0
        self.sc_mean_var = {key: None for key in self.vr.sc_vr_list}
        # y-values to plot for e) vs x-val as scaled_w
        self.gd_cost_fn = {.10: [], .15: [], .20: [], .25: [], .30: []}
        self.zero_lst = [0 for theta in self.vr.vr_list]

        # Self call
        self.init_cars()

    def init_cars(self):
        """
        A initialization function that reads and initializes the variables
        from the .csv file.
        :return: None
        """
        with open(self.cars_file_name, newline='') as cars:
            file_data = csv.reader(cars, delimiter=self.delim)
            # Go through each row.
            for row in file_data:
                # if the row is a data row.
                if row != self.vr.vr_list:
                    self.data_count += 1  # Keep a count
                    # put in directory while type casting to float.
                    for key, idx in zip(self.vr.vr_list, range(len(self.vr.vr_list))):
                        self.cars_raw_data[key].append(float(row[idx]))

    def get_mean_var(self, lst):
        """
        A function to calculate the mean and variance of the given list.
        :return: mean and variance value.
        """
        return numpy.mean(lst), numpy.var(lst)

    def calc_scaled_feature(self, feature, scaled_ft):
        """
        A function to calculate and store the scaled feature's mean and variance.
        :return: None
        """
        ft_mean, ft_variance = self.get_mean_var(self.cars_raw_data[feature])
        # Calc and store each scaled feature.
        for each_data in self.cars_raw_data[feature]:
            sw = (each_data - ft_mean) / math.sqrt(ft_variance)
            self.cars_scaled[scaled_ft].append(sw)

        # Calc and store the scaled mean and variance.
        self.sc_mean_var[scaled_ft] = (self.get_mean_var(self.cars_scaled[scaled_ft]))

    def scale_features(self):
        """
        A function to scale eac given feature.
        :return: None.
        """
        for each_ft, each_sc_ft in zip(self.vr.vr_list, self.vr.sc_vr_list):
            self.calc_scaled_feature(each_ft, each_sc_ft)

    def print_scaled_feature_and_sc_mean_var(self):
        """
        Required print fn. Prints scaled features (first 5), and the mean and variance of scaled
        weight.
        :return: None.
        """
        values = ["First 5", "Mean of scaled", "Var of scaled"]
        table = {"Print": values}
        for key in self.vr.sc_vr_list:
            # First 5 instance.
            sc_val_print = ""
            for sc_instance in self.cars_scaled[key][:5]:
                sc_val_print += (format(sc_instance, '.3f') + '\n')

            table[key] = [sc_val_print, format(self.sc_mean_var[key][0], '.5f'),
                          format(self.sc_mean_var[key][1], '.5f')]
        print(tabulate(table, headers="keys"))

    def plot_scatter_plot(self, x_val, y_val, title='', x_label='', y_label=''):
        """
        A function to plot a scatter plot and show it.
        :return: None
        """
        plot.scatter(x_val, y_val)
        plot.title(title)
        plot.axvline(x=0, c='black', label='x_axis')
        plot.axhline(y=0, c='black', label='y_axis')
        plot.xlabel(x_label)
        plot.ylabel(y_label)
        plot.legend()
        plot.grid()
        plot.show()

    def gradient_descent(self, learning_rate=.20, theta_new=None,
                         convergence_threshold=10 ** -5):
        """
        A function to find the minimum of the hypothesis, h_theta (x) := theta_0 + theta_1*x
        :param theta_new: list of theta. (default to zero list if a not provided/wrong lst len)
        :param learning_rate: The learning rate/alpha.
        :param convergence_threshold: The threshold until convergence.
        :return: Theta values.
        :type: List
        """
        #
        if theta_new is None:
            theta_new = self.zero_lst
        elif len(theta_new) != len(self.zero_lst):
            raise ValueError("Theta list of invalid size.")

        # Set the current theta as the old ones using list slicing.
        theta_old = theta_new[:]
        # Re-calc new theta values.
        theta_new = self.update_theta(theta_old, learning_rate)
        # Save the cost function value for the current learning rate and iteration.
        self.gd_cost_fn[learning_rate] = [self.cost_fn(theta_new)]

        while not self.is_converging(theta_old, theta_new, convergence_threshold):
            # Set the current value as the old values.
            theta_old = theta_new[:]
            # Re-calc new theta values.
            theta_new = self.update_theta(theta_old, learning_rate)
            # Append the cost function value for the current learning rate and iteration.
            self.gd_cost_fn[learning_rate].append(self.cost_fn(theta_new))

        # Here the values are converged.
        return theta_new

    def update_theta(self, theta_lst_old, alpha):
        """
        A function to calculate all theta new values, t_old - alpha * partial derivative of J(theta)
        w.r.t. theta.
        :param theta_lst_old: List of all the old theta values.
        :param alpha: Learning rate
        :return: theta_new values
        :type: list
        """
        m = self.data_count  # data size
        theta_lst_old = np.array(theta_lst_old)

        # Calculate the partial derivative value for all theta.
        pd_lst = [0 for theta in theta_lst_old]
        for i in range(m):
            # x array of all i^th instance.
            x_i_lst = [self.cars_scaled[sc_ft][i] for sc_ft in self.vr.sc_vr_list]
            x_i_lst[:0] = [1]  # add x_0 to be 1.

            y_i = self.cars_raw_data[self.vr.mpg][i]
            # calculate the hypothesis at the given x^(i).
            hypothesis = np.matmul(theta_lst_old, np.array(x_i_lst))
            pd_lst = [pd_lst[idx] + ((hypothesis - y_i) * x_i_lst[idx])
                      for idx in range(len(pd_lst))]
        pd_lst = [each_pd / m for each_pd in pd_lst]

        # Return the theta values.
        ret_val = [theta_lst_old[j] - (alpha * pd_lst[j]) for j in range(len(pd_lst))]
        return ret_val

    def cost_fn(self, theta_lst):
        """
        A function to calculate the value of the cost function.
        :param theta_lst: The list of all the theta.
        :return: j_theta: J(theta) value.
        """
        j_theta = 0  # Cost function value
        m = self.data_count  # data size

        # A 2d list of all the i's of features.
        x_i_lst = [self.cars_scaled[sc_ft] for sc_ft in self.vr.sc_vr_list]
        x_i_lst[:0] = [[1 for each_i in x_i_lst[0]]]
        theta_lst = np.array(theta_lst)

        # Calculate the value of J(theta) summation part.
        for i in range(0, m):
            x_i = [x_i_lst[ft_idx][i] for ft_idx in range(len(x_i_lst))]
            x_i = np.array(x_i)
            y_i = self.cars_raw_data[self.vr.mpg][i]
            j_theta += (np.matmul(theta_lst, x_i.transpose()) - y_i) ** 2
        j_theta = j_theta / (2 * m)

        # Return the cost function value.
        return j_theta

    def is_converging(self, val_old_lst, val_new_lst, threshold):
        """
        Helper for gradient descent while condition. |theta_new - theta_old| < C
        """
        converging = True
        for old_val, new_val in zip(val_old_lst, val_new_lst):
            converging = converging and (abs(new_val - old_val) < threshold)
        return converging

    def cost_fn_plot(self):
        for each_rate in [.10, .15, .20, .25, .30]:
            plot.plot(range(0, len(self.gd_cost_fn[each_rate])), self.gd_cost_fn[each_rate],
                      label=f'LR={each_rate}')

        plot.title("Cost function change over different learning rate")
        plot.xlabel('Iteration')
        plot.ylabel('Cost function value')
        plot.legend()
        plot.grid()
        plot.show()

    def x_0_lst(self, lst):
        """
        Mini function to add 1 to list.
        :param lst:
        :return:
        """
        lst[:0] = [1]
        return lst

    def normal_equation(self):
        """
        A function that uses normal equation method to find the theta values.
        :return: Theta list.
        """
        theta_lst = []
        # Create and store the X and X transpose array separately.
        X_trans = [inst_lst for inst_lst in self.cars_scaled.values()]
        # Add the x_0's as 1's.
        X_trans[:0] = [[1 for _ in range(self.data_count)]]
        X = X_trans.copy()

        X_trans = np.array(X_trans)
        X = np.array(X).transpose()

        Y = np.array(self.cars_raw_data[self.vr.mpg]).transpose()

        inverse = np.matmul(X_trans, X)
        inverse = np.linalg.inv(inverse)
        xt_y = np.matmul(X_trans, Y)

        theta_lst = np.matmul(inverse, xt_y)
        return theta_lst

