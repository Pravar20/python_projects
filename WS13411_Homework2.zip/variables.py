"""
Author:         Pravar Kochar
Date:           4/1/2023
E-mail:         pkochar1@umbc.edu
Description:    A class to hold all the variable names for HW2 functions.
"""


class Var:
    def __init__(self):
        self.mpg = "mpg"
        self.cyl = "cyl"
        self.disp = "disp"
        self.hp = "hp"
        self.drat = "drat"
        self.wt = "wt"
        self.qsec = "qsec"
        self.vs = "vs"
        self.am = "am"
        self.gear = "gear"
        self.carb = "carb"
        self.vr_list = [self.mpg, self.cyl, self.disp, self.hp, self.drat, self.wt, self.qsec,
                        self.vs, self.am, self.gear, self.carb]

        self.scaled_cyl = "scaled_cyl"
        self.scaled_disp = "scaled_disp"
        self.scaled_hp = "scaled_hp"
        self.scaled_drat = "scaled_drat"
        self.scaled_wt = "scaled_wt"
        self.scaled_qsec = "scaled_qsec"
        self.scaled_vs = "scaled_vs"
        self.scaled_am = "scaled_am"
        self.scaled_gear = "scaled_gear"
        self.scaled_carb = "scaled_carb"
        self.sc_vr_list = [self.scaled_cyl, self.scaled_disp, self.scaled_hp,
                           self.scaled_drat, self.scaled_wt, self.scaled_qsec,
                           self.scaled_vs, self.scaled_am, self.scaled_gear, self.scaled_carb]
